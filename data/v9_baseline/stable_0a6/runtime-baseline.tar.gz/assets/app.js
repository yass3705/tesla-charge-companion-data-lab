const DAYS=['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'];let defaultStations=[],stations=[],routeResults={},fxRowSeq=0;const $=id=>document.getElementById(id);
window.escapeHtml=window.escapeHtml||function(value){return String(value==null?'':value).replace(/[&<>'\"]/g,function(ch){return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','\"':'&quot;'}[ch]||ch;});};
const escapeHtml=window.escapeHtml;
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('nav button,.panel').forEach(x=>x.classList.remove('active'));b.classList.add('active');$(b.dataset.tab).classList.add('active');if(b.dataset.tab==='stations')renderStations();if(b.dataset.tab==='fx')renderFxRates();if(b.dataset.tab==='sync')loadGithubSettingsForm()});
$('simDate').valueAsDate=new Date();$('simTime').value=new Date().toTimeString().slice(0,5);$('simUnplugTime').value='';$('fUpdated').valueAsDate=new Date();$('simOrigin').value=localStorage.getItem('tccDefaultOrigin')||'';$('simMaxDistance').value=localStorage.getItem('tccMaxDistanceKm')||'20';
function oldCustomStations(){let a=JSON.parse(localStorage.getItem('tccStationsV14')||'[]');return a.filter(x=>String(x.id||'').startsWith('station-'))}
function localStations(){return JSON.parse(localStorage.getItem('tccStationsV701')||localStorage.getItem('tccStationsV66')||localStorage.getItem('tccStationsV65')||localStorage.getItem('tccStationsV64')||localStorage.getItem('tccStationsV63')||localStorage.getItem('tccStationsV62')||localStorage.getItem('tccStationsV61')||localStorage.getItem('tccStationsV60')||'null')}
function oldLocalStations(){return JSON.parse(localStorage.getItem('tccStationsV25')||'null')}
const HIDDEN_STATIONS_KEY='tccHiddenStationIdsV1';
function hiddenStationIds(){return new Set(safeJsonParse(localStorage.getItem(HIDDEN_STATIONS_KEY)||'[]',[])||[])}
function saveHiddenStationIds(ids){localStorage.setItem(HIDDEN_STATIONS_KEY,JSON.stringify([...ids]))}

const GH_SETTINGS_KEY='tccGithubSyncSettingsV1';
const GH_TOKEN_KEY='tccGithubSyncTokenV1';
const CUSTOM_DELETIONS_KEY='tccCustomStationDeletionsV1';
const GH_LAST_SYNC_KEY='tccGithubLastSyncV1';
const GH_SYNC_LOG_KEY='tccGithubSyncLogV1';
const GH_BACKUP_KEY='tccGithubCustomBackupV1';
const GH_DEVICE_KEY='tccGithubDeviceNameV1';
function githubSettings(){return safeJsonParse(localStorage.getItem(GH_SETTINGS_KEY)||'{}',{})||{}}
function githubToken(){return localStorage.getItem(GH_TOKEN_KEY)||''}
function customDeletions(){return safeJsonParse(localStorage.getItem(CUSTOM_DELETIONS_KEY)||'{}',{})||{}}
function saveCustomDeletions(value){localStorage.setItem(CUSTOM_DELETIONS_KEY,JSON.stringify(value||{}))}
function inferGithubDefaults(){
 let owner='',repo='';
 if(location.hostname.endsWith('.github.io')){
   owner=location.hostname.split('.')[0];
   repo=location.pathname.split('/').filter(Boolean)[0]||`${owner}.github.io`;
 }
 return{owner,repo,branch:'main',path:'data/custom_stations.json',autoSync:false};
}
function loadGithubSettingsForm(){
 let cfg={...inferGithubDefaults(),...githubSettings()};
 if($('ghOwner'))$('ghOwner').value=cfg.owner||'';
 if($('ghRepo'))$('ghRepo').value=cfg.repo||'';
 if($('ghBranch'))$('ghBranch').value=cfg.branch||'main';
 if($('ghPath'))$('ghPath').value=cfg.path||'data/custom_stations.json';
 if($('ghToken'))$('ghToken').value='';
 if($('ghAutoSync'))$('ghAutoSync').checked=!!cfg.autoSync;
 if($('ghReadOnly'))$('ghReadOnly').checked=!!cfg.readOnly;
 if($('ghDevice'))$('ghDevice').value=cfg.deviceName||localStorage.getItem(GH_DEVICE_KEY)||defaultDeviceName();
 renderGithubTokenState();renderGithubLastSync();renderGithubLog();
 updateGithubStatus(githubToken()&&cfg.owner&&cfg.repo?'Configuration enregistrée sur cet appareil.':'Synchronisation non configurée.',githubToken()?'good':'');
}
function saveGithubSettings(){
 let previous=githubSettings(),token=$('ghToken')?.value?.trim();
 let cfg={owner:$('ghOwner').value.trim(),repo:$('ghRepo').value.trim(),branch:$('ghBranch').value.trim()||'main',path:$('ghPath').value.trim()||'data/custom_stations.json',autoSync:!!$('ghAutoSync').checked,readOnly:!!$('ghReadOnly')?.checked,deviceName:$('ghDevice')?.value.trim()||defaultDeviceName()};
 if(!cfg.owner||!cfg.repo){alert('Renseigne le propriétaire et le dépôt GitHub.');return}
 localStorage.setItem(GH_SETTINGS_KEY,JSON.stringify(cfg));
 localStorage.setItem(GH_DEVICE_KEY,cfg.deviceName);
 if(token)localStorage.setItem(GH_TOKEN_KEY,token);
 $('ghToken').value='';
 renderGithubTokenState();updateGithubStatus(githubToken()?'Configuration enregistrée. Tu peux tester la connexion ou synchroniser.':'Configuration enregistrée, mais aucun jeton n’est disponible.',githubToken()?'good':'warn');
}
function forgetGithubToken(){
 if(!confirm('Effacer le jeton GitHub enregistré sur cet appareil ?'))return;
 localStorage.removeItem(GH_TOKEN_KEY);if($('ghToken'))$('ghToken').value='';renderGithubTokenState();updateGithubStatus('Jeton GitHub effacé de cet appareil.','warn');
}
function updateGithubStatus(message,kind=''){
 let el=$('githubSyncStatus');if(el){el.className=`small box ${kind}`;el.textContent=message}
 let badge=$('globalSyncBadge');if(badge){badge.className=`sync-badge ${kind||'idle'}`;badge.textContent=kind==='good'?'● Synchronisé':kind==='warn'?'● Synchronisation…':kind==='bad'?'● Erreur de synchro':'● Synchronisation'}
}
function renderGithubTokenState(){let el=$('ghTokenState');if(!el)return;el.textContent=githubToken()?'Jeton GitHub enregistré ✔️':'Aucun jeton enregistré';el.className=`small token-state ${githubToken()?'good':'warn'}`}
function defaultDeviceName(){let ua=navigator.userAgent||'';if(/iPhone/i.test(ua))return'iPhone';if(/iPad/i.test(ua))return'iPad';if(/Macintosh/i.test(ua))return'Mac';if(/Android/i.test(ua))return'Android';return'Navigateur';}
function relativeTime(value){let t=Date.parse(value||'');if(!Number.isFinite(t))return'';let seconds=Math.max(0,Math.round((Date.now()-t)/1000));if(seconds<10)return'à l’instant';if(seconds<60)return`il y a ${seconds} s`;let minutes=Math.round(seconds/60);if(minutes<60)return`il y a ${minutes} min`;let hours=Math.round(minutes/60);if(hours<24)return`il y a ${hours} h`;let days=Math.round(hours/24);if(days<7)return`il y a ${days} j`;return new Date(t).toLocaleDateString('fr-FR');}
function githubLastSync(){return safeJsonParse(localStorage.getItem(GH_LAST_SYNC_KEY)||'null',null)}
function setGithubLastSync(data){localStorage.setItem(GH_LAST_SYNC_KEY,JSON.stringify(data));renderGithubLastSync()}
function renderGithubLastSync(){let el=$('ghLastSync');if(!el)return;let x=githubLastSync();if(!x?.at){el.textContent='Aucune synchronisation réussie enregistrée sur cet appareil.';return}let device=x.device?` · ${x.device}`:'';let mode=x.readOnly?' · lecture seule':'';el.textContent=`Dernière synchronisation : ${relativeTime(x.at)}${device}${mode} · ${x.count} borne(s) tierce(s)`;el.title=new Date(x.at).toLocaleString('fr-FR');}
function githubSyncLog(){return safeJsonParse(localStorage.getItem(GH_SYNC_LOG_KEY)||'[]',[])||[]}
function addGithubLog(type,message){let log=githubSyncLog();log.unshift({at:new Date().toISOString(),type,message});localStorage.setItem(GH_SYNC_LOG_KEY,JSON.stringify(log.slice(0,8)));renderGithubLog()}
function renderGithubLog(){let el=$('ghSyncLog');if(!el)return;let log=githubSyncLog();el.innerHTML=log.length?log.map(x=>`<div class="log-entry ${x.type}"><b>${new Date(x.at).toLocaleString('fr-FR')}</b><br>${escapeHtml(x.message)}</div>`).join(''):'<div class="small">Aucun événement de synchronisation.</div>'}
function friendlyGithubError(status,detail=''){if(status===401)return'Jeton invalide ou expiré.';if(status===403)return'Accès refusé : vérifie que le jeton autorise Contents en lecture et écriture sur ce dépôt.';if(status===404)return'Dépôt, branche ou fichier introuvable.';if(status===409)return'Conflit GitHub détecté : les données distantes ont changé. Réessaie la synchronisation.';if(status===422)return'Requête refusée par GitHub : vérifie la branche et le chemin du fichier.';return detail||`Erreur GitHub (${status}).`}
function utf8ToBase64(text){let bytes=new TextEncoder().encode(text),binary='';bytes.forEach(b=>binary+=String.fromCharCode(b));return btoa(binary)}
function base64ToUtf8(value){let binary=atob((value||'').replace(/\n/g,'')),bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));return new TextDecoder().decode(bytes)}
function isoTime(value){let t=Date.parse(value||'');return Number.isFinite(t)?t:0}
function stationSyncTime(st,fallback=''){return st?._syncUpdatedAt||st?.syncUpdatedAt||fallback||((st?.lastUpdated||'')+'T00:00:00Z')}
function customStationsForSync(){return stations.filter(st=>st.source!=='teslaSupercharger').map(st=>({...st,_syncUpdatedAt:stationSyncTime(st,st.lastUpdated?`${st.lastUpdated}T00:00:00Z`:'1970-01-01T00:00:00Z')}))}
function parseCustomCloudData(data){
 if(Array.isArray(data))return{schemaVersion:1,updatedAt:'',lastDevice:'',stations:data,deletedIds:{}};
 return{schemaVersion:Number(data?.schemaVersion||2),updatedAt:data?.updatedAt||'',lastDevice:data?.lastDevice||'',stations:Array.isArray(data?.stations)?data.stations:[],deletedIds:data?.deletedIds&&typeof data.deletedIds==='object'?data.deletedIds:{}};
}
function mergeCustomCloudStates(remote){
 let localStations=customStationsForSync(),localDeleted=customDeletions(),remoteState=parseCustomCloudData(remote),records=new Map();
 function offerStation(st,fallback){let id=st?.id;if(!id)return;let time=stationSyncTime(st,fallback),candidate={type:'station',time,value:{...st,_syncUpdatedAt:time}};let current=records.get(id);if(!current||isoTime(candidate.time)>=isoTime(current.time))records.set(id,candidate)}
 function offerDelete(id,time){if(!id)return;let candidate={type:'delete',time:time||new Date(0).toISOString()};let current=records.get(id);if(!current||isoTime(candidate.time)>=isoTime(current.time))records.set(id,candidate)}
 remoteState.stations.forEach(st=>offerStation(st,remoteState.updatedAt));
 Object.entries(remoteState.deletedIds||{}).forEach(([id,time])=>offerDelete(id,time));
 localStations.forEach(st=>offerStation(st,''));
 Object.entries(localDeleted).forEach(([id,time])=>offerDelete(id,time));
 let mergedStations=[],mergedDeleted={};
 for(let [id,rec] of records){if(rec.type==='delete')mergedDeleted[id]=rec.time;else mergedStations.push(rec.value)}
 mergedStations.sort((x,y)=>(x.name||'').localeCompare(y.name||'','fr'));
 let cfg=githubSettings();return{schemaVersion:2,updatedAt:new Date().toISOString(),lastDevice:cfg.deviceName||defaultDeviceName(),stations:mergedStations,deletedIds:mergedDeleted};
}
function applyMergedCustomState(state){
 let cloud=parseCustomCloudData(state),teslaOnly=stations.filter(st=>st.source==='teslaSupercharger');
 stations=[...teslaOnly,...cloud.stations.map(st=>normalizeStation(st))];
 saveCustomDeletions(cloud.deletedIds||{});saveLocal();renderStations();
}
function githubApiHeaders(){return{'Accept':'application/vnd.github+json','Authorization':`Bearer ${githubToken()}`,'X-GitHub-Api-Version':'2022-11-28'}}
function githubContentUrl(cfg){return `https://api.github.com/repos/${encodeURIComponent(cfg.owner)}/${encodeURIComponent(cfg.repo)}/contents/${cfg.path.split('/').map(encodeURIComponent).join('/')}?ref=${encodeURIComponent(cfg.branch||'main')}`}
async function readGithubCustomFile(cfg){
 let response=await fetch(githubContentUrl(cfg),{headers:githubApiHeaders(),cache:'no-store'});
 if(response.status===404)return{sha:null,data:{schemaVersion:2,stations:[],deletedIds:{}}};
 if(!response.ok){let detail=await response.json().catch(()=>({}));throw new Error(friendlyGithubError(response.status,detail.message))}
 let payload=await response.json();return{sha:payload.sha,data:JSON.parse(base64ToUtf8(payload.content))};
}
async function writeGithubCustomFile(cfg,state,sha){
 let url=githubContentUrl(cfg).split('?')[0];
 let body={message:`Synchronisation des bornes tierces (${new Date().toLocaleString('fr-FR')})`,content:utf8ToBase64(JSON.stringify(state,null,2)),branch:cfg.branch||'main'};
 if(sha)body.sha=sha;
 let response=await fetch(url,{method:'PUT',headers:{...githubApiHeaders(),'Content-Type':'application/json'},body:JSON.stringify(body)});
 if(!response.ok){let detail=await response.json().catch(()=>({}));let err=new Error(friendlyGithubError(response.status,detail.message));err.status=response.status;throw err}
 return response.json();
}
let githubSyncPromise=null;
async function syncGithubNow(silent=false){
 if(githubSyncPromise)return githubSyncPromise;
 githubSyncPromise=(async()=>{
  let cfg=githubSettings();
  if(!cfg.owner||!cfg.repo||!githubToken())throw new Error('Configure le dépôt et le jeton GitHub sur cet appareil.');
  updateGithubStatus('Synchronisation en cours…','warn');
  localStorage.setItem(GH_BACKUP_KEY,JSON.stringify({at:new Date().toISOString(),stations:customStationsForSync(),deletedIds:customDeletions()}));
  let remote=await readGithubCustomFile(cfg),merged;
  if(cfg.readOnly){
   merged=parseCustomCloudData(remote.data);
   applyMergedCustomState(merged);
  }else{
   merged=mergeCustomCloudStates(remote.data);
   try{await writeGithubCustomFile(cfg,merged,remote.sha)}catch(err){if(err.status!==409)throw err;remote=await readGithubCustomFile(cfg);merged=mergeCustomCloudStates(remote.data);await writeGithubCustomFile(cfg,merged,remote.sha)}
   applyMergedCustomState(merged);
  }
  let syncDevice=cfg.readOnly?(merged.lastDevice||'GitHub'):(cfg.deviceName||defaultDeviceName());
  setGithubLastSync({at:new Date().toISOString(),count:merged.stations.length,device:syncDevice,readOnly:!!cfg.readOnly});
  let msg=cfg.readOnly?`Lecture GitHub réussie : ${merged.stations.length} borne(s) tierce(s) récupérée(s), aucune écriture effectuée.`:`Synchronisation réussie : ${merged.stations.length} borne(s) tierce(s), ${Object.keys(merged.deletedIds).length} suppression(s) mémorisée(s).`;
  updateGithubStatus(msg,'good');addGithubLog('good',msg);return merged;
 })().catch(err=>{let msg=`Échec : ${err.message}`;updateGithubStatus(msg,'bad');addGithubLog('bad',msg);if(!silent)alert(`Synchronisation GitHub impossible : ${err.message}`);throw err}).finally(()=>githubSyncPromise=null);
 return githubSyncPromise;
}
async function testGithubConnection(){
 try{let cfg=githubSettings();if(!cfg.owner||!cfg.repo||!githubToken())throw new Error('Enregistre d’abord le dépôt et le jeton.');updateGithubStatus('Test de connexion en cours…','warn');let r=await fetch(`https://api.github.com/repos/${encodeURIComponent(cfg.owner)}/${encodeURIComponent(cfg.repo)}/branches/${encodeURIComponent(cfg.branch||'main')}`,{headers:githubApiHeaders(),cache:'no-store'});if(!r.ok){let d=await r.json().catch(()=>({}));throw new Error(friendlyGithubError(r.status,d.message))}updateGithubStatus('Connexion GitHub validée : dépôt et branche accessibles.','good');addGithubLog('good','Test de connexion GitHub réussi.')}catch(err){updateGithubStatus(`Échec du test : ${err.message}`,'bad');addGithubLog('bad',`Test de connexion : ${err.message}`);alert(`Test GitHub impossible : ${err.message}`)}
}
function queueGithubSync(){let cfg=githubSettings();if(cfg.autoSync&&githubToken())setTimeout(()=>syncGithubNow(true).catch(()=>{}),100)}
function exportGithubBackup(){let payload={format:'Tesla Charge Companion backup',version:'7.3.0',exportedAt:new Date().toISOString(),device:githubSettings().deviceName||defaultDeviceName(),stations:customStationsForSync(),deletedIds:customDeletions(),settings:{...githubSettings(),token:undefined}};let blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`tcc-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),500);updateGithubStatus('Sauvegarde locale exportée.','good');addGithubLog('good','Sauvegarde locale exportée.')}
function chooseGithubBackup(){if($('ghImportFile'))$('ghImportFile').click()}
async function importGithubBackup(input){let file=input?.files?.[0];if(!file)return;try{let data=JSON.parse(await file.text()),cloud=parseCustomCloudData(data?.stations?{schemaVersion:2,stations:data.stations,deletedIds:data.deletedIds||{},updatedAt:data.exportedAt||new Date().toISOString()}:data);if(!Array.isArray(cloud.stations))throw new Error('Format de sauvegarde non reconnu.');if(!confirm(`Importer ${cloud.stations.length} borne(s) tierce(s) sur cet appareil ?`))return;applyMergedCustomState(cloud);updateGithubStatus(`Sauvegarde importée : ${cloud.stations.length} borne(s) tierce(s).`,'good');addGithubLog('good',`Sauvegarde importée : ${cloud.stations.length} borne(s).`)}catch(err){updateGithubStatus(`Import impossible : ${err.message}`,'bad');alert(`Import impossible : ${err.message}`)}finally{input.value=''}}

function isPublishedStation(id){return defaultStations.some(st=>st.id===id)}
function normalizePricingCurrency(pricing){
 if(!pricing)return pricing;
 if(pricing.type==='rules')(pricing.rules||[]).forEach(r=>r.currency=(r.currency||pricing.currency||'EUR').toUpperCase());
 else pricing.currency=(pricing.currency||'EUR').toUpperCase();
 return pricing;
}
function legacyConfiguration(st){
 return [{id:'main',label:`${st.kind||'AC'} ${Number(st.powerKw||11)} kW`,kind:st.kind||'AC',powerKw:Number(st.powerKw||11),stalls:Number(st.stalls||0)}];
}
function normalizeConfigurations(configs,st){
 let source=Array.isArray(configs)&&configs.length?configs:legacyConfiguration(st);
 return source.map((c,i)=>({
   id:c.id||`config-${i+1}`,
   label:c.label||`${c.kind||'AC'} ${Number(c.powerKw||11)} kW`,
   kind:c.kind||'AC',
   powerKw:Number(c.powerKw||11),
   stalls:Math.max(0,Math.round(Number(c.stalls||0))),
   pricing:normalizePricingCurrency(c.pricing||st.pricing||{type:'kwh',pricePerKwh:.29,currency:'EUR'})
 }));
}
function normalizeStation(st,defaults={}){
 let merged={...defaults,...st};
 // Pour les fiches publiées, les coordonnées GPS officielles restent prioritaires
 // sur une ancienne copie locale ou une adresse textuelle modifiée.
 let officialLat=Number(defaults.latitude),officialLon=Number(defaults.longitude);
 if(Number.isFinite(officialLat)&&Number.isFinite(officialLon)){
   merged.latitude=officialLat;
   merged.longitude=officialLon;
 }
 // Une nouvelle configuration publiée est adoptée seulement si l'ancienne fiche locale n'en possédait pas.
 let configurations=Array.isArray(st.chargingConfigurations)&&st.chargingConfigurations.length?st.chargingConfigurations:defaults.chargingConfigurations;
 configurations=normalizeConfigurations(configurations,merged);
 let totalStalls=configurations.reduce((sum,c)=>sum+c.stalls,0);
 return {...merged,
   operator:st.operator||defaults.operator||((st.source||defaults.source)==='teslaSupercharger'?'Tesla':''),
   chargingConfigurations:configurations,
   stalls:totalStalls||st.stalls||defaults.stalls||0,
   kind:configurations[0].kind,
   powerKw:configurations[0].powerKw,
   pricing:normalizePricingCurrency(st.pricing||defaults.pricing)
 };
}
function stationConfigurations(st){return normalizeConfigurations(st.chargingConfigurations,st)}
function expandConfigurations(baseStations){
 return baseStations.flatMap(st=>stationConfigurations(st).map((cfg,index)=>({
   ...st,
   id:`${st.id}::${cfg.id}`,
   baseStationId:st.id,
   configurationId:cfg.id,
   configurationLabel:cfg.label||`${cfg.kind} ${cfg.powerKw} kW`,
   kind:cfg.kind,
   powerKw:cfg.powerKw,
   stalls:cfg.stalls,
   pricing:cfg.pricing||st.pricing,
   totalSiteStalls:st.stalls,
   configurationIndex:index
 })));
}
function saveLocal(){localStorage.setItem('tccStationsV701',JSON.stringify(stations))}
function mins(t){let [h,m]=t.split(':').map(Number);return h*60+m}
function fmtMin(m){m=Math.max(0,m);let h=Math.floor(m/60),n=Math.round(m%60);return h?`${h} h ${String(n).padStart(2,'0')}`:`${n} min`}
function finishTime(dateStr,timeStr,durationMin){
 let start=new Date(`${dateStr}T${timeStr}:00`);
 let end=new Date(start.getTime()+Math.round(durationMin*60000));
 let startDay=new Date(start.getFullYear(),start.getMonth(),start.getDate());
 let endDay=new Date(end.getFullYear(),end.getMonth(),end.getDate());
 let delta=Math.round((endDay-startDay)/86400000);
 let hm=`${String(end.getHours()).padStart(2,'0')}:${String(end.getMinutes()).padStart(2,'0')}`;
 if(delta===0)return hm;
 if(delta===1)return `demain à ${hm}`;
 return `${end.toLocaleDateString('fr-FR')} à ${hm}`;
}
function saveDefaultOrigin(){
 let origin=$('simOrigin').value.trim();
 if(!origin){alert('Saisis une adresse de départ.');return}
 localStorage.setItem('tccDefaultOrigin',origin);
 alert('Adresse enregistrée sur cet appareil.');
}
function sleep(ms){return new Promise(resolve=>setTimeout(resolve,ms))}
function geoCache(){return JSON.parse(localStorage.getItem('tccGeoCacheV1')||'{}')}
function saveGeoCache(cache){localStorage.setItem('tccGeoCacheV1',JSON.stringify(cache))}
function routeCacheKey(origin,stationIds){return `tccRoutes:${origin.toLowerCase()}::${stationIds.join(',')}`}
function getCurrentPosition(){
 return new Promise((resolve,reject)=>{
  if(!navigator.geolocation)return reject(new Error('Géolocalisation indisponible sur cet appareil.'));
  navigator.geolocation.getCurrentPosition(
   p=>resolve({lat:p.coords.latitude,lon:p.coords.longitude,label:'Ma position'}),
   ()=>reject(new Error('La position actuelle n’a pas été autorisée.')),
   {enableHighAccuracy:true,timeout:12000,maximumAge:300000}
  )
 })
}
async function geocodeAddress(address){
 let raw=address.trim();
 let gps=raw.match(/^\s*(-?\d{1,2}(?:\.\d+)?)\s*[,;]\s*(-?\d{1,3}(?:\.\d+)?)\s*$/);
 if(gps){
   let lat=Number(gps[1]),lon=Number(gps[2]);
   if(lat>=-90&&lat<=90&&lon>=-180&&lon<=180)return{lat,lon,label:`${lat}, ${lon}`};
 }
 let key=raw.toLowerCase(),cache=geoCache();
 if(cache[key])return cache[key];
 let url='https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&accept-language=fr&q='+encodeURIComponent(raw);
 let response=await fetch(url,{headers:{'Accept':'application/json'}});
 if(!response.ok)throw new Error(`Géocodage impossible (${response.status}).`);
 let data=await response.json();
 if(!data.length)throw new Error(`Adresse non reconnue : ${address}`);
 let result={lat:+data[0].lat,lon:+data[0].lon,label:data[0].display_name};
 cache[key]=result;saveGeoCache(cache);
 return result
}
async function resolveOrigin(originText){
 if(!originText||originText.trim().toLowerCase()==='ma position')return getCurrentPosition();
 return geocodeAddress(originText)
}

function haversineKm(aLat,aLon,bLat,bLon){
 const R=6371,toRad=x=>x*Math.PI/180;
 let dLat=toRad(bLat-aLat),dLon=toRad(bLon-aLon);
 let q=Math.sin(dLat/2)**2+Math.cos(toRad(aLat))*Math.cos(toRad(bLat))*Math.sin(dLon/2)**2;
 return 2*R*Math.asin(Math.sqrt(q));
}
async function candidateStations(filterMode='tesla',maxDistanceKm=0){
 let originText=$('simOrigin').value.trim()||localStorage.getItem('tccDefaultOrigin')||'Ma position';
 let origin=await resolveOrigin(originText);

 // Ne jamais réutiliser une distance calculée pour une ancienne adresse de départ.
 routeResults={};

 let candidates=stations.filter(s=>
   !s.temporarilyUnavailable &&
   (filterMode==='all'||(s.operator||'').toLowerCase()==='tesla'||s.source==='teslaSupercharger')
 );
 let cache=geoCache();

 for(let st of candidates){
   if(!Number.isFinite(st.latitude)||!Number.isFinite(st.longitude)){
     let key=(st.address||'').trim().toLowerCase();
     if(cache[key]){
       st.latitude=cache[key].lat;
       st.longitude=cache[key].lon;
     }else if(st.address){
       try{
         let geo=await geocodeAddress(st.address);
         st.latitude=geo.lat;
         st.longitude=geo.lon;
         cache=geoCache();
       }catch(e){}
     }
   }
 }

 candidates=candidates.filter(s=>Number.isFinite(s.latitude)&&Number.isFinite(s.longitude));
 candidates.forEach(s=>s._airKm=haversineKm(origin.lat,origin.lon,s.latitude,s.longitude));

 // Une borne dont la distance à vol d’oiseau dépasse déjà la limite
 // ne peut pas respecter cette limite par la route.
 if(maxDistanceKm>0){
   candidates=candidates.filter(s=>s._airKm<=maxDistanceKm);
 }

 let shortlist=candidates
   .sort((a,b)=>a._airKm-b._airKm)
   .slice(0,Math.min(80,candidates.length));

 // Calcul par lots pour éviter les URL OSRM trop longues.
 const batchSize=24;
 for(let offset=0;offset<shortlist.length;offset+=batchSize){
   let batch=shortlist.slice(offset,offset+batchSize);
   try{
     let coords=[`${origin.lon},${origin.lat}`,...batch.map(s=>`${s.longitude},${s.latitude}`)].join(';');
     let destinations=batch.map((_,i)=>i+1).join(';');
     let url=`https://router.project-osrm.org/table/v1/driving/${coords}?sources=0&destinations=${destinations}&annotations=distance,duration`;
     let response=await fetch(url);
     if(!response.ok)continue;
     let data=await response.json();
     if(data.code!=='Ok')continue;

     batch.forEach((s,i)=>{
       let d=data.distances?.[0]?.[i];
       let t=data.durations?.[0]?.[i];
       if(d!=null&&t!=null){
         routeResults[s.id]={
           distanceKm:d/1000,
           durationMin:t/60,
           originLabel:origin.label
         };
       }
     });
   }catch(e){}
 }

 // Application stricte : une distance routière connue au-delà de la limite
 // est systématiquement exclue. Sans résultat OSRM, on conserve seulement
 // les bornes dont la distance de repli affichée respecte la limite.
 if(maxDistanceKm>0){
   shortlist=shortlist.filter(s=>{
     let effectiveDistance=routeResults[s.id]?.distanceKm??s._airKm;
     return Number.isFinite(effectiveDistance)&&effectiveDistance<=maxDistanceKm;
   });
 }

 return{origin,stations:shortlist,maxDistanceKm};
}
function rankingWeights(mode){
 if(mode==='price')return{price:.7,distance:.3};
 if(mode==='distance')return{price:.3,distance:.7};
 return{price:.5,distance:.5};
}
function rankByPriceDistance(rows,mode){
 let available=rows.filter(x=>!x.r.unavailable&&!x.r.unknown&&Number.isFinite(x.r.total));
 let unknown=rows.filter(x=>!x.r.unavailable&&(x.r.unknown||!Number.isFinite(x.r.total)))
   .sort((a,b)=>a.distanceKm-b.distanceKm);
 if(!available.length)return unknown.slice(0,20);
 let costs=available.map(x=>x.r.total),distances=available.map(x=>x.distanceKm);
 let minC=Math.min(...costs),maxC=Math.max(...costs),minD=Math.min(...distances),maxD=Math.max(...distances),w=rankingWeights(mode);
 available.forEach(x=>{
   let cn=maxC===minC?0:(x.r.total-minC)/(maxC-minC);
   let dn=maxD===minD?0:(x.distanceKm-minD)/(maxD-minD);
   x.score=w.price*cn+w.distance*dn;
 });
 return [...available.sort((a,b)=>a.score-b.score),...unknown].slice(0,20);
}
async function calculateRoutes(){
 let button=$('routeButton');button.classList.add('loading');button.textContent='Calcul en cours…';
 $('routeStatus').textContent='Calcul des distances et du classement…';
 try{
   await compare();
 }finally{
   button.classList.remove('loading');button.textContent='Recalculer les 20 meilleures bornes';
 }
}
function routeHtml(st){
 let r=routeResults[st.id];
 if(!r)return '';
 if(r.error)return `<div class="routeinfo warn">${r.error}</div>`;
 return `<div class="routeinfo"><b>${r.distanceKm.toFixed(1)} km · ${Math.round(r.durationMin)} min</b><br>Trajet routier estimé depuis l’adresse de départ</div>`;
}

function dcCurvePower(soc,condition,profile,stationMax){
 let pts=[[0,175],[10,175],[20,170],[30,160],[40,145],[50,125],[60,105],[70,85],[80,60],[85,42],[90,28],[95,16],[98,10],[100,6]];
 let p=pts[pts.length-1][1];
 for(let i=1;i<pts.length;i++){
  if(soc<=pts[i][0]){let [x1,y1]=pts[i-1],[x2,y2]=pts[i];p=y1+(y2-y1)*(soc-x1)/(x2-x1);break}
 }
 let cf=condition==='warm'?1:(condition==='cold'?.68:.86);
 let pf=profile==='optimistic'?1.08:(profile==='conservative'?.88:1);
 return Math.max(3,Math.min(stationMax,p*cf*pf));
}
function acPowerAtSoc(soc,stationMax){
 let p=Math.min(11,stationMax);
 if(soc<97)return p;
 if(soc<99)return p*.72;
 return p*.42;
}


const SUPPORTED_FX=[
 {code:'EUR',name:'Euro',region:'Europe'},
 {code:'CHF',name:'Franc suisse',region:'Europe'},
 {code:'GBP',name:'Livre sterling',region:'Europe'},
 {code:'NOK',name:'Couronne norvégienne',region:'Europe'},
 {code:'SEK',name:'Couronne suédoise',region:'Europe'},
 {code:'DKK',name:'Couronne danoise',region:'Europe'},
 {code:'PLN',name:'Zloty polonais',region:'Europe'},
 {code:'CZK',name:'Couronne tchèque',region:'Europe'},
 {code:'HUF',name:'Forint hongrois',region:'Europe'},
 {code:'RON',name:'Leu roumain',region:'Europe'},
 {code:'BGN',name:'Lev bulgare',region:'Europe'},
 {code:'MAD',name:'Dirham marocain',region:'Maghreb'},
 {code:'DZD',name:'Dinar algérien',region:'Maghreb'},
 {code:'TND',name:'Dinar tunisien',region:'Maghreb'}
];
const DEFAULT_FX={
 EUR:1,CHF:.93,GBP:.84,NOK:11.7,SEK:11.2,DKK:7.46,PLN:4.25,CZK:24.6,
 HUF:400,RON:5.08,BGN:1.95583,MAD:10.8,DZD:151,TND:3.38
};
const FX_PUBLISHED_KEY='tccFxPublishedV3';
const FX_OVERRIDE_KEY='tccFxOverridesV2';
const FX_MIGRATION_KEY='tccFxMigrationV2Done';

function safeJsonParse(value,fallback=null){
 try{return JSON.parse(value)}catch(e){return fallback}
}
function migrateOldFxOverrides(){
 if(localStorage.getItem(FX_MIGRATION_KEY)==='1')return;
 let existing=safeJsonParse(localStorage.getItem(FX_OVERRIDE_KEY)||'null');
 if(existing&&typeof existing==='object'){
   localStorage.setItem(FX_MIGRATION_KEY,'1');
   return;
 }
 let old=safeJsonParse(localStorage.getItem('tccFxRatesV1')||'null');
 let overrides={};
 if(old?.rates){
   for(let [code,rate] of Object.entries(old.rates)){
     code=String(code).toUpperCase();
     if(code!=='EUR'&&SUPPORTED_FX.some(x=>x.code===code)&&Number(rate)>0)overrides[code]=Number(rate);
   }
 }
 localStorage.setItem(FX_OVERRIDE_KEY,JSON.stringify(overrides));
 localStorage.setItem(FX_MIGRATION_KEY,'1');
}
function getFxOverrides(){
 migrateOldFxOverrides();
 return safeJsonParse(localStorage.getItem(FX_OVERRIDE_KEY)||'{}',{})||{};
}
function getPublishedFx(){
 return window.publishedFxState||
   safeJsonParse(localStorage.getItem(FX_PUBLISHED_KEY)||'null')||
   {base:'EUR',rates:{...DEFAULT_FX},updated:null,source:'fallback intégré'};
}
function getFxState(){
 let published=getPublishedFx(),overrides=getFxOverrides();
 return{
   base:'EUR',
   rates:{...DEFAULT_FX,...(published.rates||{}),...overrides,EUR:1},
   updated:published.updated||null,
   providerDate:published.providerDate||published.updated||null,
   checkedAt:published.checkedAt||null,
   source:published.source||'fallback intégré',
   overrides
 };
}
async function loadPublishedFx(cacheBust=true){
 try{
   let suffix=`?v=${Date.now()}`;
   let response=await fetch(`data/exchange_rates.json${suffix}`,{cache:'no-store',headers:{'Cache-Control':'no-cache'}});
   if(!response.ok)throw new Error(`Erreur ${response.status}`);
   let data=await response.json();
   let state={
     base:'EUR',
     rates:{...DEFAULT_FX,EUR:1,...(data.rates||{})},
     updated:data.date||null,
     providerDate:data.providerDate||data.date||null,
     checkedAt:data.checkedAt||null,
     source:data.source||'GitHub quotidien'
   };
   window.publishedFxState=state;
   localStorage.setItem(FX_PUBLISHED_KEY,JSON.stringify(state));
   return state;
 }catch(e){
   let cached=safeJsonParse(localStorage.getItem(FX_PUBLISHED_KEY)||'null');
   if(cached)window.publishedFxState=cached;
   return cached;
 }
}
function fxToEur(amount,currency){
 let code=(currency||'EUR').toUpperCase(),rate=getFxState().rates?.[code];
 if(code==='EUR')return Number(amount)||0;
 if(!Number.isFinite(Number(rate))||Number(rate)<=0)throw new Error(`Taux ${code} manquant`);
 return (Number(amount)||0)/Number(rate);
}
function eurToFx(amountEur,currency){
 let code=(currency||'EUR').toUpperCase(),rate=getFxState().rates?.[code];
 if(code==='EUR')return Number(amountEur)||0;
 if(!Number.isFinite(Number(rate))||Number(rate)<=0)return null;
 return (Number(amountEur)||0)*Number(rate);
}
function currencyInfo(code){
 return SUPPORTED_FX.find(item=>item.code===code)||{code,name:code,region:'Autre'};
}
function formatMoney(amount,code){
 try{
   return new Intl.NumberFormat('fr-FR',{
     style:'currency',currency:code,minimumFractionDigits:2,maximumFractionDigits:2
   }).format(amount);
 }catch(e){return `${Number(amount).toFixed(2)} ${code}`}
}
function localCostHtml(totalEur,currencies=[]){
 let unique=[...new Set((currencies||[]).map(x=>String(x).toUpperCase()))];
 if(unique.length===1&&unique[0]!=='EUR'){
   let code=unique[0],local=eurToFx(totalEur,code);
   if(local!==null)return `<div class="cost">${formatMoney(local,code)}<div class="cost-eur">≈ ${formatMoney(totalEur,'EUR')}</div></div>`;
 }
 return `<div class="cost">${formatMoney(totalEur,'EUR')}</div>`;
}
function publishedFxIsFallback(){
 let published=getPublishedFx();
 return !published.updated || String(published.source||'').toLowerCase().includes('fallback');
}
function renderFxRates(){
 let state=getFxState(),overrides=state.overrides||{},fallback=publishedFxIsFallback();
 $('fxRows').innerHTML='';
 fxRowSeq=0;
 let currentRegion='';
 for(let item of SUPPORTED_FX){
   if(item.region!==currentRegion){
     currentRegion=item.region;
     $('fxRows').insertAdjacentHTML('beforeend',`<h4 class="fx-region">${currentRegion}</h4>`);
   }
   let sourceState=item.code==='EUR'?'base':
     (Object.prototype.hasOwnProperty.call(overrides,item.code)?'manual':
     (fallback?'fallback':'published'));
   addFxRow(item.code,state.rates[item.code],item.name,sourceState);
 }
 let overrideCount=Object.keys(overrides).length;
 let dateText=state.updated?`Taux publiés du ${state.updated}`:'Aucune date de publication';
 let checkedText='';
 if(state.checkedAt){
   let checkedDate=new Date(state.checkedAt);
   checkedText=Number.isNaN(checkedDate.getTime())?` · Dernière vérification : ${state.checkedAt}`:` · Dernière vérification : ${checkedDate.toLocaleString('fr-FR')}`;
 }
 let sourceText=state.source||'source inconnue';
 let warning=fallback?'<br><span class="warn">⚠ Valeurs de secours : lance une actualisation avant une comparaison multi-devise.</span>':'';
 $('fxStatus').innerHTML=`${dateText}${checkedText} · Source : ${sourceText}${overrideCount?` · ${overrideCount} correction(s) manuelle(s)`:''}${warning}`;
}
function addFxRow(code='',rate='',name='',sourceState='published'){
 fxRowSeq+=1;let id=`fx-${fxRowSeq}`,disabled=code==='EUR'?'disabled':'';
 let labels={
   base:'<span class="fx-pill fx-base">Base</span>',
   manual:'<span class="fx-pill fx-manual">Manuel</span>',
   fallback:'<span class="fx-pill fx-fallback">Secours</span>',
   published:'<span class="fx-pill fx-published">Publié</span>'
 };
 $('fxRows').insertAdjacentHTML('beforeend',`<div class="fx-row" id="${id}" data-code="${code}">
 <div><label>Devise</label><b>${code}</b><div class="small">${name||code}</div></div>
 <div><label>1 EUR =</label><input class="fx-rate" type="number" min="0" step=".000001" value="${rate??''}" ${disabled}></div>
 <div class="fx-source">${labels[sourceState]||labels.published}</div>
 </div>`);
}
function saveFxRates(){
 let overrides={};
 [...document.querySelectorAll('.fx-row')].forEach(row=>{
   let code=(row.dataset.code||'').toUpperCase();
   let rate=Number(row.querySelector('.fx-rate')?.value);
   if(code&&code!=='EUR'&&Number.isFinite(rate)&&rate>0){
     let published=Number(getPublishedFx().rates?.[code]??DEFAULT_FX[code]);
     if(!Number.isFinite(published)||Math.abs(rate-published)>1e-9)overrides[code]=rate;
   }
 });
 localStorage.setItem(FX_OVERRIDE_KEY,JSON.stringify(overrides));
 renderFxRates();
 alert('Corrections manuelles enregistrées sur cet appareil.');
}
function resetFxOverrides(){
 if(!confirm('Effacer toutes les corrections manuelles de devises ?'))return;
 localStorage.setItem(FX_OVERRIDE_KEY,'{}');
 localStorage.setItem(FX_MIGRATION_KEY,'1');
 localStorage.removeItem('tccFxRatesV1');
 renderFxRates();
 alert('Toutes les corrections manuelles ont été effacées.');
}
async function updateLiveFx(){
 $('fxStatus').textContent='Actualisation en cours…';
 try{
   let state=await loadPublishedFx(true);
   if(!state)throw new Error('Aucun fichier de taux disponible');
   renderFxRates();
   if(state.checkedAt){
     let d=new Date(state.checkedAt);
     if(!Number.isNaN(d.getTime())) $('fxStatus').insertAdjacentHTML('beforeend',`<br><span class="ok">✓ Fichier vérifié le ${d.toLocaleString('fr-FR')}.</span>`);
   }
   if($('dataFreshness')){
     let fxDate=state.updated||'valeurs de secours';
     let current=$('dataFreshness').innerHTML||'';
     $('dataFreshness').innerHTML=current.replace(/Taux de change\s*:\s*[^<]*/i,`Taux de change : ${fxDate}`);
   }
 }catch(err){
   $('fxStatus').innerHTML=`<span class="bad">Actualisation impossible : ${err.message}. Le dernier taux valide reste utilisé.</span>`;
 }
}
let pricingRuleSeq=0;
function ruleId(){pricingRuleSeq+=1;return `rule-${pricingRuleSeq}`}

function pricingRuleTemplate(rule={}){
 let id=ruleId(),scope=rule.scope||'allDay',billing=rule.billing||'kwh';
 return `<div class="pricing-rule" data-rule-id="${id}">
   <div class="rule-title"><b>Tarif</b><button type="button" class="danger" onclick="removePricingRule('${id}')">Supprimer</button></div>
   <div class="pricing-grid">
     <div><label>Application</label><select class="pr-scope" onchange="refreshPricingRule('${id}')">
       <option value="allDay" ${scope==='allDay'?'selected':''}>Toute la journée</option>
       <option value="timeWindow" ${scope==='timeWindow'?'selected':''}>Créneau horaire</option>
     </select></div>
     <div><label>Mode de facturation</label><select class="pr-billing" onchange="refreshPricingRule('${id}')">
       <option value="kwh" ${billing==='kwh'?'selected':''}>Tarif au kWh</option>
       <option value="minute" ${billing==='minute'?'selected':''}>Tarif fixe à la minute</option>
       <option value="powerMinute" ${billing==='powerMinute'?'selected':''}>À la minute selon la puissance délivrée</option>
     </select></div>
     <div><label>Devise</label><input class="pr-currency" list="currencyCodes" maxlength="3" value="${(rule.currency||'EUR').toUpperCase()}"></div>
     <div class="pr-time"><label>Début du créneau</label><input class="pr-start" type="time" value="${rule.start||'00:00'}"></div>
     <div class="pr-time"><label>Fin du créneau</label><input class="pr-end" type="time" value="${rule.end||'24:00'}"></div>
     <div class="pr-kwh"><label>Prix / kWh (dans la devise choisie)</label><input class="pr-price-kwh" type="number" min="0" step=".001" value="${rule.pricePerKwh??0.29}"></div>
     <div class="pr-minute"><label>Prix de charge / min</label><input class="pr-charge-min" type="number" min="0" step=".001" value="${rule.chargePerMinute??0}"></div>
     <div class="pr-power-bands full">
       <div class="row" style="justify-content:space-between">
         <b>Tranches de puissance</b>
         <button type="button" class="secondary" onclick="addPowerBand('${id}')">Ajouter une tranche</button>
       </div>
       <div class="small" style="margin:6px 0">La puissance instantanée estimée détermine le tarif appliqué à chaque minute.</div>
       <div class="power-band-list"></div>
     </div>
     <div><label>Frais fixes / parking</label><input class="pr-connection" type="number" min="0" step=".01" value="${rule.connectionFee??0}"></div>
     <div><label>Congestion / occupation après charge, par min</label><input class="pr-idle-min" type="number" min="0" step=".001" value="${rule.idlePerMinute??0}"></div>
     <div><label>Frais après une durée / min</label><input class="pr-after-min-rate" type="number" min="0" step=".001" value="${rule.afterMinutesRate??0}"></div>
     <div><label>Déclenchement après (minutes)</label><input class="pr-after-min-threshold" type="number" min="0" step="1" value="${rule.afterMinutesThreshold??0}"></div>
     <div><label>Plafond de ces frais (€)</label><input class="pr-after-min-cap" type="number" min="0" step=".01" value="${rule.afterMinutesCap??0}"><div class="small">0 = aucun plafond.</div></div>
     <div><label>Plafond valable à partir de</label><input class="pr-cap-start" type="time" value="${rule.afterMinutesCapStart||'00:00'}"></div>
     <div><label>Plafond valable jusqu’à</label><input class="pr-cap-end" type="time" value="${rule.afterMinutesCapEnd||'24:00'}"><div class="small">00:00–24:00 = plafond toute la journée.</div></div>
   </div>
 </div>`;
}
let powerBandSeq=0;
function powerBandTemplate(band={}){
 let id=`power-band-${++powerBandSeq}`;
 return `<div class="power-band-row" data-power-band="${id}">
   <div><label>De (kW)</label><input class="pb-min" type="number" min="0" step="1" value="${band.minKw??0}"></div>
   <div><label>À (kW)</label><input class="pb-max" type="number" min="1" step="1" value="${band.maxKw??60}"></div>
   <div><label>Tarif / min</label><input class="pb-rate" type="number" min="0" step=".001" value="${band.ratePerMinute??0}"></div>
   <button type="button" class="danger" onclick="removePowerBand('${id}')">Supprimer</button>
 </div>`;
}
function loadPowerBands(ruleEl,bands){
 let list=ruleEl.querySelector('.power-band-list');
 list.innerHTML='';
 let source=Array.isArray(bands)&&bands.length?bands:[
   {minKw:0,maxKw:60,ratePerMinute:1.10},
   {minKw:60,maxKw:100,ratePerMinute:2.30},
   {minKw:100,maxKw:150,ratePerMinute:3.50}
 ];
 source.forEach(b=>list.insertAdjacentHTML('beforeend',powerBandTemplate(b)));
}
function addPowerBand(ruleId,band={}){
 let ruleEl=document.querySelector(`[data-rule-id="${ruleId}"]`);
 if(ruleEl)ruleEl.querySelector('.power-band-list').insertAdjacentHTML('beforeend',powerBandTemplate(band));
}
function removePowerBand(id){
 let row=document.querySelector(`[data-power-band="${id}"]`);
 if(!row)return;
 let list=row.parentElement;
 row.remove();
 if(list&&!list.children.length)list.insertAdjacentHTML('beforeend',powerBandTemplate({}));
}
function readPowerBands(ruleEl){
 return [...ruleEl.querySelectorAll('.power-band-row')].map(row=>({
   minKw:Math.max(0,Number(row.querySelector('.pb-min').value||0)),
   maxKw:Math.max(0,Number(row.querySelector('.pb-max').value||0)),
   ratePerMinute:Math.max(0,Number(row.querySelector('.pb-rate').value||0))
 })).filter(b=>b.maxKw>b.minKw).sort((a,b)=>a.minKw-b.minKw);
}
function addPricingRuleTo(container,rule={}){
 container.insertAdjacentHTML('beforeend',pricingRuleTemplate(rule));
 let el=container.lastElementChild;
 loadPowerBands(el,rule.powerBands);
 refreshPricingRule(el.dataset.ruleId);
}
function addPricingRule(rule={}){let container=$('pricingRules');if(container)addPricingRuleTo(container,rule)}
function removePricingRule(id){
 let el=document.querySelector(`[data-rule-id="${id}"]`);
 if(!el)return;
 let container=el.parentElement;
 el.remove();
 if(container&&!container.children.length)addPricingRuleTo(container,{});
}
function refreshPricingRule(id){
 let el=document.querySelector(`[data-rule-id="${id}"]`);if(!el)return;
 let scope=el.querySelector('.pr-scope').value,billing=el.querySelector('.pr-billing').value;
 el.querySelectorAll('.pr-time').forEach(x=>x.classList.toggle('hidden',scope!=='timeWindow'));
 el.querySelectorAll('.pr-kwh').forEach(x=>x.classList.toggle('hidden',billing!=='kwh'));
 el.querySelectorAll('.pr-minute').forEach(x=>x.classList.toggle('hidden',billing!=='minute'));
 el.querySelectorAll('.pr-power-bands').forEach(x=>x.classList.toggle('hidden',billing!=='powerMinute'));
}
function readPricingRulesFrom(container){
 return {type:'rules',rules:[...container.querySelectorAll('.pricing-rule')].map(el=>({
   scope:el.querySelector('.pr-scope').value,
   start:el.querySelector('.pr-start').value||'00:00',
   end:el.querySelector('.pr-end').value||'24:00',
   billing:el.querySelector('.pr-billing').value,
   currency:(el.querySelector('.pr-currency').value||'EUR').trim().toUpperCase(),
   pricePerKwh:+el.querySelector('.pr-price-kwh').value||0,
   chargePerMinute:+el.querySelector('.pr-charge-min').value||0,
   connectionFee:+el.querySelector('.pr-connection').value||0,
   idlePerMinute:+el.querySelector('.pr-idle-min').value||0,
   powerBands:readPowerBands(el),
   afterMinutesRate:+el.querySelector('.pr-after-min-rate').value||0,
   afterMinutesThreshold:Math.max(0,Math.round(+el.querySelector('.pr-after-min-threshold').value||0)),
   afterMinutesCap:+el.querySelector('.pr-after-min-cap').value||0,
   afterMinutesCapStart:el.querySelector('.pr-cap-start').value||'00:00',
   afterMinutesCapEnd:el.querySelector('.pr-cap-end').value||'24:00'
 }))};
}
function readPricingRules(){let container=$('pricingRules');return container?readPricingRulesFrom(container):{type:'rules',rules:[]}}
function legacyPricingToRules(pricing){
 if(!pricing)return[{scope:'allDay',billing:'kwh',currency:'EUR',pricePerKwh:.29,connectionFee:0,idlePerMinute:0}];
 if(pricing.type==='rules')return(pricing.rules||[]).map(r=>({...r,currency:(r.currency||pricing.currency||'EUR').toUpperCase()}));
 if(pricing.type==='kwh')return[{scope:'allDay',billing:'kwh',currency:(pricing.currency||'EUR').toUpperCase(),pricePerKwh:pricing.pricePerKwh||0,connectionFee:0,idlePerMinute:0}];
 if(pricing.type==='timeBandsKwh')return(pricing.bands||[]).map(b=>({scope:'timeWindow',start:b.start,end:b.end,billing:'kwh',currency:(b.currency||pricing.currency||'EUR').toUpperCase(),pricePerKwh:b.pricePerKwh||0,connectionFee:0,idlePerMinute:0}));
 if(pricing.type==='kwhPlusParking')return[{
   scope:'allDay',
   billing:'kwh',
   currency:(pricing.currency||'EUR').toUpperCase(),
   pricePerKwh:pricing.pricePerKwh||0,
   connectionFee:0,
   idlePerMinute:0,
   afterMinutesRate:pricing.parkingPerMinute||0,
   afterMinutesThreshold:pricing.freeMinutes||0,
   afterMinutesCap:pricing.nightCap||0,
   afterMinutesCapStart:pricing.nightStart||'00:00',
   afterMinutesCapEnd:pricing.nightEnd||'24:00'
 }];
 if(pricing.type==='accessPlusTime')return[
  {scope:'timeWindow',start:pricing.dayStart||'08:00',end:pricing.dayEnd||'20:00',billing:'minute',chargePerMinute:(pricing.dayPerHour||0)/60,connectionFee:pricing.accessFee||0,idlePerMinute:0},
  {scope:'timeWindow',start:pricing.dayEnd||'20:00',end:pricing.dayStart||'08:00',billing:'minute',chargePerMinute:(pricing.nightPerHour||0)/60,connectionFee:pricing.accessFee||0,idlePerMinute:0}
 ];
 if(pricing.type==='freeWindowUnknownAfter')return[{scope:'allDay',billing:'minute',chargePerMinute:0,connectionFee:0,idlePerMinute:0}];
 return[{scope:'allDay',billing:'kwh',pricePerKwh:.29,connectionFee:0,idlePerMinute:0}];
}
function loadPricingRulesInto(container,pricing){
 container.innerHTML='';
 let rules=legacyPricingToRules(pricing);
 if(!rules.length)rules=[{}];
 rules.forEach(rule=>addPricingRuleTo(container,rule));
}
function loadPricingRules(pricing){let container=$('pricingRules');if(container)loadPricingRulesInto(container,pricing)}
function toggleAccessMode(){
 let scheduled=$('fAccessMode').value==='schedule';$('scheduleBox').classList.toggle('hidden',!scheduled);
}
function minuteOfSession(startMin,offset){return(startMin+offset)%1440}
function inWindow(m,start,end){
 let s=mins(start),e=end==='24:00'?1440:mins(end);if(s===e)return true;return s<e?(m>=s&&m<e):(m>=s||m<e);
}
function ruleForMinute(rules,m){
 let specific=(rules||[]).find(r=>r.scope==='timeWindow'&&inWindow(m,r.start||'00:00',r.end||'24:00'));
 return specific||(rules||[]).find(r=>r.scope==='allDay')||null;
}
function unplugDurationMinutes(startTime,chargeMinutes,unplugTime){
 if(!unplugTime)return chargeMinutes;
 let start=mins(startTime),unplug=mins(unplugTime),duration=unplug-start;if(duration<0)duration+=1440;
 return Math.max(chargeMinutes,duration);
}
function priceWithRules(pp,startMin,chargeMinutes,billedEnergy,unplugTime,startTime,powerSegments=[]){
 let rules=pp.rules||[],startRule=ruleForMinute(rules,startMin);if(!startRule)return{error:'Aucun tarif applicable à l’heure de branchement'};
 let currencies=new Set(),connection=0,chargeCost=0,idleCost=0,durationSurcharge=0,energyPerMinute=chargeMinutes>0?billedEnergy/chargeMinutes:0;
 try{
   currencies.add((startRule.currency||'EUR').toUpperCase());
   connection=fxToEur(startRule.connectionFee||0,startRule.currency||'EUR');
   for(let i=0;i<Math.ceil(chargeMinutes);i++){
     let m=minuteOfSession(startMin,i),rule=ruleForMinute(rules,m);if(!rule)return{error:'Aucun tarif défini pour une partie de la charge'};
     let fraction=Math.min(1,chargeMinutes-i),currency=(rule.currency||'EUR').toUpperCase();currencies.add(currency);
     let raw=0;
     if(rule.billing==='kwh'){
       raw=energyPerMinute*fraction*(rule.pricePerKwh||0);
     }else if(rule.billing==='powerMinute'){
       let estimatedPower=powerAtElapsed(powerSegments,i+fraction/2);
       let band=powerBandAt(rule,estimatedPower);
       if(!band)return{error:`Aucune tranche tarifaire ne couvre une puissance estimée de ${estimatedPower.toFixed(0)} kW`};
       raw=fraction*Number(band.ratePerMinute||0);
     }else{
       raw=fraction*(rule.chargePerMinute||0);
     }
     chargeCost+=fxToEur(raw,currency);
   }
   let occupied=unplugDurationMinutes(startTime,chargeMinutes,unplugTime);
   for(let i=Math.ceil(chargeMinutes);i<Math.ceil(occupied);i++){
     let rule=ruleForMinute(rules,minuteOfSession(startMin,i));if(!rule)continue;
     let currency=(rule.currency||'EUR').toUpperCase();currencies.add(currency);
     idleCost+=fxToEur(rule.idlePerMinute||0,currency);
   }

   // Frais liés à la durée totale de connexion, même si la voiture charge encore.
   // Exemple : 0,05 unité monétaire/min après 180 min.
   const surchargeByRule=new Map();
   for(let i=0;i<Math.ceil(occupied);i++){
     let rule=ruleForMinute(rules,minuteOfSession(startMin,i));if(!rule)continue;
     let threshold=Math.max(0,Number(rule.afterMinutesThreshold||0));
     let rate=Math.max(0,Number(rule.afterMinutesRate||0));
     if(rate<=0||i<threshold)continue;
     let fraction=Math.min(1,occupied-i);
     let currency=(rule.currency||'EUR').toUpperCase();currencies.add(currency);
     let key=rule;
     let current=surchargeByRule.get(key)||0;
     surchargeByRule.set(key,current+fxToEur(rate*fraction,currency));
   }

   for(const [rule,rawAmount] of surchargeByRule.entries()){
     let amount=rawAmount;
     let cap=Math.max(0,Number(rule.afterMinutesCap||0));
     if(cap>0){
       let capStart=rule.afterMinutesCapStart||'00:00';
       let capEnd=rule.afterMinutesCapEnd||'24:00';
       let hasCappedWindow=false;
       for(let i=Math.max(0,Number(rule.afterMinutesThreshold||0));i<Math.ceil(occupied);i++){
         if(inWindow(minuteOfSession(startMin,i),capStart,capEnd)){hasCappedWindow=true;break}
       }
       if(hasCappedWindow){
         amount=Math.min(amount,fxToEur(cap,rule.currency||'EUR'));
       }
     }
     durationSurcharge+=amount;
   }

   return{
     total:connection+chargeCost+idleCost+durationSurcharge,
     connection,chargeCost,idleCost,durationSurcharge,
     occupiedMinutes:occupied,currencies:[...currencies]
   };
 }catch(err){return{error:err.message}}
}
function daySchedule(st,dateStr){let d=new Date(dateStr+'T12:00:00');return st.access?.days?.[String(d.getDay())]}
function accessStatus(st,dateStr,timeStr){if(!st.access?.limited)return{canStart:true,remaining:Infinity,label:'Accessible 24 h/24'};let sch=daySchedule(st,dateStr);if(!sch||!sch.open)return{canStart:false,remaining:0,label:'Fermé ce jour'};let t=mins(timeStr),s=mins(sch.start),e=sch.end==='24:00'?1440:mins(sch.end);if(t<s||t>=e)return{canStart:false,remaining:0,label:`Accessible ${sch.start}–${sch.end}`};return{canStart:true,remaining:e-t,label:`Accessible ${sch.start}–${sch.end}`,close:sch.end}}
function chargeBase(st,now,target,condition='normal',profile='realistic'){
 const cap=75,loss=st.kind==='AC'?.10:.05;
 let batt=cap*(target-now)/100,billed=batt/(1-loss),minutes=0,segments=[];
 for(let soc=now;soc<target;soc+=1){
  let next=Math.min(target,soc+1),batteryKwh=cap*(next-soc)/100,wallKwh=batteryKwh/(1-loss);
  let power=st.kind==='AC'?acPowerAtSoc((soc+next)/2,st.powerKw):dcCurvePower((soc+next)/2,condition,profile,st.powerKw);
  let segmentMinutes=(wallKwh/power)*60;
  segments.push({startMin:minutes,endMin:minutes+segmentMinutes,powerKw:power,wallKwh});
  minutes+=segmentMinutes;
 }
 return{batt,billed,minutes,avg:billed/(minutes/60),segments}
}
function powerAtElapsed(segments,elapsedMin){
 let segment=(segments||[]).find(s=>elapsedMin>=s.startMin&&elapsedMin<s.endMin);
 return segment?.powerKw??segments?.[segments.length-1]?.powerKw??0;
}
function powerBandAt(rule,powerKw){
 let bands=[...(rule.powerBands||[])].sort((a,b)=>Number(a.minKw||0)-Number(b.minKw||0));
 return bands.find((b,i)=>{
   let min=Number(b.minKw||0),max=Number(b.maxKw||0);
   return powerKw>=min&&(powerKw<max||(i===bands.length-1&&powerKw<=max));
 });
}
function bandAt(pp,m){return pp.bands.find(x=>m>=mins(x.start)&&m<(x.end==='24:00'?1440:mins(x.end)))}
function energyCostBands(pp,startMin,durationMin,totalEnergy){let cost=0,remaining=durationMin,cur=startMin,energyPerMin=totalEnergy/durationMin;while(remaining>0){let m=cur%1440,b=bandAt(pp,m);if(!b)return null;let end=b.end==='24:00'?1440:mins(b.end),chunk=Math.min(remaining,end-m);cost+=chunk*energyPerMin*b.pricePerKwh;cur+=chunk;remaining-=chunk}return cost}
function minutesInWindow(start,duration,ws,we){let s=mins(ws),e=mins(we),c=0;for(let i=0;i<Math.ceil(duration);i++){let m=(start+i)%1440;if(s<e?(m>=s&&m<e):(m>=s||m<e))c++}return c}
function simulate(st,dateStr,timeStr,now,target,condition='normal',profile='realistic',unplugTime=''){
 let a=accessStatus(st,dateStr,timeStr);if(!a.canStart)return{unavailable:true,message:a.label};
 let b=chargeBase(st,now,target,condition,profile),allowed=b.minutes,truncated=false;
 if(st.access?.limited&&st.access.afterCloseMode==='must_stop'&&b.minutes>a.remaining){allowed=a.remaining;truncated=true}
 let ratio=allowed/b.minutes,deliveredBilled=b.billed*ratio,deliveredBatt=b.batt*ratio,reached=now+(target-now)*ratio,start=mins(timeStr),pp=st.pricing,total=0,unknown=false;
 let pricingDetails={connection:0,chargeCost:0,idleCost:0,occupiedMinutes:allowed};
 if(pp?.type==='rules'){
   if(!(pp.rules||[]).length)return{...b,allowed,deliveredBilled,deliveredBatt,reached,total:NaN,truncated,access:a,unknown:true,message:'Tarif non disponible',pricingDetails};
   let priced=priceWithRules(pp,start,allowed,deliveredBilled,unplugTime,timeStr,b.segments);
   if(priced.error)return{...b,allowed,deliveredBilled,deliveredBatt,reached,total:NaN,truncated,access:a,unknown:true,message:priced.error,pricingDetails};
   total=priced.total;pricingDetails=priced
 }
 else if(pp.type==='kwh')total=fxToEur(deliveredBilled*pp.pricePerKwh,pp.currency||'EUR');
 else if(pp.type==='timeBandsKwh'){let c=energyCostBands(pp,start,allowed,deliveredBilled);if(c===null)return{unavailable:true,message:'Tarif absent pour une partie de la session'};total=c}
 else if(pp.type==='kwhPlusParking'){let parking=Math.max(0,allowed-pp.freeMinutes)*pp.parkingPerMinute;if(minutesInWindow((start+pp.freeMinutes)%1440,Math.max(0,allowed-pp.freeMinutes),pp.nightStart,pp.nightEnd)>0)parking=Math.min(parking,pp.nightCap);total=deliveredBilled*pp.pricePerKwh+parking;pricingDetails.idleCost=parking}
 else if(pp.type==='accessPlusTime'){let paid=Math.max(0,allowed-pp.freeMinutes),dayM=minutesInWindow((start+pp.freeMinutes)%1440,paid,pp.dayStart,pp.dayEnd);total=pp.accessFee+dayM*(pp.dayPerHour/60);pricingDetails.connection=pp.accessFee||0;pricingDetails.chargeCost=dayM*(pp.dayPerHour/60)}
 else if(pp.type==='freeWindowUnknownAfter'){if(allowed<=pp.freeMinutes)total=0;else unknown=true}
 return{...b,allowed,deliveredBilled,deliveredBatt,reached,total,truncated,access:a,unknown,pricingDetails}
}
async function compare(){
 let now=+$('simNow').value,target=+$('simTarget').value,date=$('simDate').value,time=$('simTime').value;
 let condition=$('simCondition').value,profile=$('simProfile').value,unplugTime=$('simUnplugTime').value;
 let filterMode=$('simOperatorFilter').value,rankingMode=$('simRanking').value;
 let rawMaxDistance=$('simMaxDistance').value.trim();
 let maxDistanceKm=rawMaxDistance===''?0:Math.max(0,Number(rawMaxDistance)||0);
 localStorage.setItem('tccMaxDistanceKm',maxDistanceKm>0?String(maxDistanceKm):'0');
 if(target<=now){$('results').innerHTML='<div class="bad">Objectif invalide.</div>';return}
 $('results').innerHTML='<div class="small">Calcul du classement prix + distance…</div>';
 try{
   let prepared=await candidateStations(filterMode,maxDistanceKm);
   let expanded=expandConfigurations(prepared.stations);
   let rows=expanded.map(st=>{
     let baseId=st.baseStationId||st.id;
     let route=routeResults[baseId];
     let distanceKm=route?.distanceKm??st._airKm;
     return{st,distanceKm,r:simulate(st,date,time,now,target,condition,profile,unplugTime)};
   });

   // Garde-fou final : aucune configuration au-delà de la limite
   // ne peut arriver dans le classement, quel que soit le nombre de résultats.
   if(maxDistanceKm>0){
     rows=rows.filter(row=>Number.isFinite(row.distanceKm)&&row.distanceKm<=maxDistanceKm);
   }

   let ranked=rankByPriceDistance(rows,rankingMode);
   let radiusText=maxDistanceKm>0?` à ${maxDistanceKm} km maximum (limite stricte)`:' sans limite de distance';
   $('routeStatus').innerHTML=`<span class="good">${ranked.length} borne(s) affichée(s) depuis ${prepared.origin.label}${radiusText}.</span>`;
   if(!ranked.length){
     let message=maxDistanceKm>0
       ?`Aucune borne exploitable n’a été trouvée dans un rayon de ${maxDistanceKm} km. Augmente la distance maximale ou retire la limite.`
       :'Aucune borne exploitable n’a été trouvée.';
     $('results').innerHTML=`<div class="warn">${message}</div>`;
     return
   }
   $('results').innerHTML=ranked.map(({st,r,distanceKm,score},idx)=>{
    let route=routeResults[st.baseStationId||st.id],distance=route?`${route.distanceKm.toFixed(1)} km · ${Math.round(route.durationMin)} min`:`≈ ${distanceKm.toFixed(1)} km à vol d’oiseau`;
    let operator=st.operator||'Opérateur non renseigné';
    let currencies=r.pricingDetails?.currencies?.length?r.pricingDetails.currencies.join(', '):'EUR';
    let info='';
    if(st.access?.limited&&st.access.afterCloseMode==='exit_allowed')info=`<div class="good small">✓ Entrée avant ${r.access.close}; la charge peut continuer après fermeture.</div>`;
    if(r.truncated)info=`<div class="warn small"><b>Charge arrêtée à ${r.access.close}</b><br>Niveau estimé : ${r.reached.toFixed(0)} %.</div>`;
    let taper=target>80&&st.kind==='DC'?`<div class="warn small">Le ralentissement au-dessus de 80 % est inclus.</div>`:'';
    let breakdown=r.pricingDetails&&(r.pricingDetails.connection||r.pricingDetails.idleCost||r.pricingDetails.durationSurcharge)?`<div class="small">Parking / fixe : ${(r.pricingDetails.connection||0).toFixed(2)} € · Congestion / après charge : ${(r.pricingDetails.idleCost||0).toFixed(2)} € · Frais après durée : ${(r.pricingDetails.durationSurcharge||0).toFixed(2)} €</div>`:'';
    return`<div class="station"><div class="station-head"><div><h3>${idx+1}. ${st.name} — ${st.configurationLabel||`${st.kind} ${st.powerKw} kW`}</h3><span class="badge operator-badge">${operator}</span><span class="badge">${st.kind}</span><span class="badge">${st.powerKw} kW</span>${st.stalls?`<span class="badge">${st.stalls} point${st.stalls>1?'s':''} sur cette puissance</span>`:''}${st.totalSiteStalls?`<span class="badge">${st.totalSiteStalls} au total sur le site</span>`:''}<span class="badge currency-badge">${currencies==='EUR'?'EUR':`${currencies} · comparaison EUR`}</span><span class="badge">MAJ ${st.lastUpdated||'—'}</span></div>${Number.isFinite(r.total)?localCostHtml(r.total,r.pricingDetails?.currencies||['EUR']):'<div class="cost">Tarif à compléter</div>'}</div><div class="routeinfo"><b>${distance}</b></div><div class="scorebox">Classement combiné prix + distance</div><div class="small">${r.access?.label||'Accès disponible'}<br><b>${Number.isFinite(r.allowed)?fmtMin(r.allowed):'—'}</b>${Number.isFinite(r.allowed)?` · fin estimée : <b>${finishTime(date,time,r.allowed)}</b>`:''}<br>${Number.isFinite(r.deliveredBilled)?`${r.deliveredBilled.toFixed(1)} kWh facturés · puissance moyenne ≈ ${r.avg.toFixed(0)} kW`:r.message||'Tarif non disponible'}</div>${breakdown}${info}${taper}<div class="row" style="margin-top:9px"><button class="secondary" onclick="window.open('${mapsUrl(st)}','_blank')">Itinéraire Google Maps</button>${st.teslaUrl?`<button class="secondary" onclick="window.open('${st.teslaUrl}','_blank')">Fiche Tesla</button>`:''}</div></div>`;
   }).join('');
 }catch(err){
   $('results').innerHTML=`<div class="bad">${err.message}</div>`;
   $('routeStatus').innerHTML='<span class="bad">Impossible de calculer le classement. Vérifie l’adresse, la devise et les taux.</span>';
 }
}
function stationDestination(stOrAddress){
 if(stOrAddress&&typeof stOrAddress==='object'){
   let lat=Number(stOrAddress.latitude),lon=Number(stOrAddress.longitude);
   if(Number.isFinite(lat)&&lat>=-90&&lat<=90&&Number.isFinite(lon)&&lon>=-180&&lon<=180){
     return `${lat},${lon}`;
   }
   return String(stOrAddress.address||'').trim();
 }
 return String(stOrAddress||'').trim();
}
function mapsUrl(stOrAddress){
 let destination=stationDestination(stOrAddress);
 let origin=$('simOrigin')?.value?.trim()||localStorage.getItem('tccDefaultOrigin')||'';
 let url='https://www.google.com/maps/dir/?api=1&travelmode=driving&destination='+encodeURIComponent(destination);
 if(origin&&origin.toLowerCase()!=='ma position')url+='&origin='+encodeURIComponent(origin);
 return url
}

function showTeslaSyncInfo(){
 $('teslaSyncInfo').innerHTML=`1. Ouvre la <b>Fiche Tesla</b> de la station. 2. Vérifie le prix membre Tesla et ses créneaux. 3. Clique sur <b>Modifier</b>. 4. Mets à jour les tarifs, la devise et la date. 5. Enregistre la borne. Les changements restent sur cet appareil.`;
}
function renderStations(){
 $('stationList').innerHTML=stations.map(st=>`<div class="station ${st.temporarilyUnavailable?'disabled-station':''}">
 <div class="station-head">
  <div>
   <h3>${st.name}</h3>${st.operator?`<span class="badge operator-badge">${st.operator}</span>`:''}${st.stalls?`<span class="badge">${st.stalls} point${st.stalls>1?'s':''} au total</span>`:''}<div style="margin-top:6px">${stationConfigurations(st).map(c=>{let rules=legacyPricingToRules(c.pricing),first=rules[0],price=first?(first.billing==='kwh'?`${Number(first.pricePerKwh||0).toFixed(2)} ${first.currency||'EUR'}/kWh`:`${Number(first.chargePerMinute||0).toFixed(3)} ${first.currency||'EUR'}/min`):'tarif à définir';return`<span class="badge">${c.stalls?`${c.stalls} × `:''}${c.kind} ${c.powerKw} kW · ${price}</span>`}).join('')}</div>
   ${st.temporarilyUnavailable?'<span class="badge badge-unavailable">Temporairement indisponible</span>':''}
   <div class="small">${st.address||'Aucune adresse'}<br>${st.access?.limited?(st.access.afterCloseMode==='exit_allowed'?'Charge possible après fermeture':'Arrêt obligatoire à la fermeture'):'Accessible 24 h/24'}</div>
   ${routeHtml(st)}
  </div>
 </div>
 <div class="row" style="margin-top:10px">
  ${st.address?`<button class="secondary" onclick="window.open('${mapsUrl(st)}','_blank')">Itinéraire Google Maps</button>`:''}
  <button class="secondary" onclick="toggleStationAvailability('${st.id}')">${st.temporarilyUnavailable?'Réactiver':'Marquer indisponible'}</button>
  <button class="secondary" onclick="editStation('${st.id}')">Modifier</button>
  <button class="danger" onclick="deleteStation('${st.id}')">Supprimer</button>
 </div>
 </div>`).join('')
}
function toggleStationAvailability(id){
 let st=stations.find(x=>x.id===id);
 if(!st)return;
 st.temporarilyUnavailable=!st.temporarilyUnavailable;
 saveLocal();
 renderStations();
 compare();
}
let chargingConfigSeq=0;
function chargingConfigurationTemplate(config={}){
 let id=`charge-config-${++chargingConfigSeq}`;
 let kind=config.kind||'AC',power=Number(config.powerKw||11),stalls=Math.max(0,Math.round(Number(config.stalls||0)));
 return `<div class="charge-config" data-charge-config="${id}">
   <div class="row" style="justify-content:space-between">
     <b>Configuration</b>
     <button type="button" class="danger" onclick="removeChargingConfiguration('${id}')">Supprimer</button>
   </div>
   <div class="charge-config-grid">
     <div><label>Libellé</label><input class="cc-label" value="${config.label||`${kind} ${power} kW`}"></div>
     <div><label>Type</label><select class="cc-kind"><option ${kind==='AC'?'selected':''}>AC</option><option ${kind==='DC'?'selected':''}>DC</option></select></div>
     <div><label>Puissance (kW)</label><input class="cc-power" type="number" min="1" step="1" value="${power}"></div>
     <div><label>Nombre de points</label><input class="cc-stalls" type="number" min="0" step="1" value="${stalls}"></div>
   </div>
   <div class="box" style="margin-top:12px">
     <div class="row" style="justify-content:space-between">
       <b>Tarification de cette puissance</b>
       <button type="button" class="secondary cc-add-price">Ajouter un tarif</button>
     </div>
     <div class="small" style="margin-top:6px">Tarif au kWh ou à la minute, frais de connexion et d’occupation, toute la journée ou par créneau.</div>
     <div class="cc-pricing-rules"></div>
   </div>
 </div>`;
}
function addChargingConfiguration(config={}){
 $('chargingConfigurations').insertAdjacentHTML('beforeend',chargingConfigurationTemplate(config));
 let card=$('chargingConfigurations').lastElementChild;
 let pricingContainer=card.querySelector('.cc-pricing-rules');
 loadPricingRulesInto(pricingContainer,config.pricing||{type:'kwh',pricePerKwh:.29,currency:'EUR'});
 card.querySelector('.cc-add-price').onclick=()=>addPricingRuleTo(pricingContainer,{});
}
function removeChargingConfiguration(id){
 let el=document.querySelector(`[data-charge-config="${id}"]`);
 if(el)el.remove();
 if(!$('chargingConfigurations').children.length)addChargingConfiguration();
}
function loadChargingConfigurations(configs,st={}){
 $('chargingConfigurations').innerHTML='';
 normalizeConfigurations(configs,st).forEach(addChargingConfiguration);
}
function readChargingConfigurations(){
 let configs=[...document.querySelectorAll('#chargingConfigurations .charge-config')].map((el,i)=>{
   let kind=el.querySelector('.cc-kind').value;
   let power=Math.max(1,Number(el.querySelector('.cc-power').value||11));
   return{
     id:`config-${i+1}`,
     label:el.querySelector('.cc-label').value.trim()||`${kind} ${power} kW`,
     kind,
     powerKw:power,
     stalls:Math.max(0,Math.round(Number(el.querySelector('.cc-stalls').value||0))),
     pricing:readPricingRulesFrom(el.querySelector('.cc-pricing-rules'))
   };
 });
 return configs.length?configs:[{
   id:'main',label:'AC 11 kW',kind:'AC',powerKw:11,stalls:0,
   pricing:{type:'rules',rules:[{scope:'allDay',billing:'kwh',currency:'EUR',pricePerKwh:.29,chargePerMinute:0,connectionFee:0,idlePerMinute:0,afterMinutesRate:0,afterMinutesThreshold:0,afterMinutesCap:0,afterMinutesCapStart:'00:00',afterMinutesCapEnd:'24:00'}]}
 }];
}
function buildDays(){$('daysForm').innerHTML=DAYS.map((d,i)=>`<div class="dayrow"><b>${d}</b><label><input id="dOpen${i}" type="checkbox"> ouvert</label><input id="dStart${i}" type="time" value="09:00"><input id="dEnd${i}" type="time" value="20:00"></div>`).join('')}
function resetForm(){
 $('formTitle').textContent='Ajouter une borne';$('editId').value='';$('fName').value='';$('fOperator').value='';$('fAddress').value='';loadChargingConfigurations([{id:'main',label:'AC 11 kW',kind:'AC',powerKw:11,stalls:1}]);
 $('fAccessMode').value='always';$('fTemporarilyUnavailable').checked=false;$('fCloseMode').value='must_stop';$('fCloseNote').value='';$('fUpdated').valueAsDate=new Date();
 for(let i=0;i<7;i++){$('dOpen'+i).checked=true;$('dStart'+i).value='00:00';$('dEnd'+i).value='24:00'}
 toggleAccessMode();
}
function editStation(id){
 let st=stations.find(x=>x.id===id);if(!st)return;document.querySelector('[data-tab="edit"]').click();
 $('formTitle').textContent='Modifier la borne';$('editId').value=st.id;$('fName').value=st.name;$('fOperator').value=st.operator||'';$('fAddress').value=st.address||'';loadChargingConfigurations(st.chargingConfigurations,st);
 $('fAccessMode').value=st.access?.limited?'schedule':'always';$('fTemporarilyUnavailable').checked=!!st.temporarilyUnavailable;$('fCloseMode').value=st.access?.afterCloseMode||'must_stop';$('fCloseNote').value=st.access?.afterCloseNote||'';$('fUpdated').value=st.lastUpdated||new Date().toISOString().slice(0,10);
 for(let i=0;i<7;i++){let d=st.access?.days?.[String(i)]||{open:true,start:'00:00',end:'24:00'};$('dOpen'+i).checked=d.open;$('dStart'+i).value=d.start;$('dEnd'+i).value=d.end}
 toggleAccessMode();
}
function saveStation(){
 let id=$('editId').value||('station-'+Date.now()),days={};
 for(let i=0;i<7;i++)days[String(i)]={open:$('dOpen'+i).checked,start:$('dStart'+i).value,end:$('dEnd'+i).value};
 let i=stations.findIndex(x=>x.id===id),existing=i>=0?stations[i]:{};
 let configs=readChargingConfigurations(),totalStalls=configs.reduce((sum,c)=>sum+c.stalls,0),first=configs[0];
 let st={...existing,id,name:$('fName').value.trim()||'Nouvelle borne',operator:$('fOperator').value.trim(),stalls:totalStalls,address:$('fAddress').value.trim(),kind:first.kind,source:existing.source||'custom',powerKw:first.powerKw,chargingConfigurations:configs,pricing:first.pricing,lastUpdated:$('fUpdated').value,temporarilyUnavailable:$('fTemporarilyUnavailable').checked,_syncUpdatedAt:new Date().toISOString(),access:{limited:$('fAccessMode').value==='schedule',days,afterCloseMode:$('fCloseMode').value,afterCloseNote:$('fCloseNote').value.trim()}};
 if(i>=0)stations[i]=st;else stations.push(st);let deletions=customDeletions();delete deletions[id];saveCustomDeletions(deletions);saveLocal();renderStations();resetForm();queueGithubSync();alert('Borne enregistrée sur cet appareil.'+(githubSettings().autoSync&&githubToken()?' Synchronisation GitHub lancée.':''));
}
function deleteStation(id){
 let st=stations.find(x=>x.id===id);
 if(!st)return;
 let published=st.source==='teslaSupercharger';
 let message=published
   ?`Masquer « ${st.name} » sur cet appareil ? La station restera dans le fichier GitHub et pourra être restaurée en effaçant les données locales.`
   :`Supprimer définitivement « ${st.name} » de cet appareil ?`;
 if(!confirm(message))return;
 stations=stations.filter(x=>x.id!==id);
 if(published){
   let hidden=hiddenStationIds();hidden.add(id);saveHiddenStationIds(hidden);
 }else{
   let deletions=customDeletions();deletions[id]=new Date().toISOString();saveCustomDeletions(deletions);
 }
 saveLocal();
 renderStations();
 compare();
 if(!published)queueGithubSync();
}
loadPublishedFx(true).then(()=>Promise.all([
 fetch('data/tesla_stations.json').then(r=>r.json()),
 fetch('data/custom_stations.json').then(r=>r.json()),
 fetch('data/metadata.json').then(r=>r.json()).catch(()=>({}))
])).then(([teslaData,customData,metadata])=>{
 let publishedCustom=parseCustomCloudData(customData);saveCustomDeletions({...publishedCustom.deletedIds,...customDeletions()});
 defaultStations=[...teslaData,...publishedCustom.stations].map(s=>normalizeStation(s));
 let hidden=hiddenStationIds();
 let saved=localStations();
 if(saved){
   stations=saved
     .filter(s=>!hidden.has(s.id))
     .map(s=>normalizeStation(s,defaultStations.find(d=>d.id===s.id)||{}));
   // Ajouter les nouvelles stations publiées, sauf celles masquées volontairement sur cet appareil.
   for(let official of defaultStations){
     if(!hidden.has(official.id)&&!stations.some(s=>s.id===official.id))stations.push(official);
   }
 }else{
   let old=oldLocalStations();
   stations=(old?old.map(s=>normalizeStation(s,defaultStations.find(d=>d.id===s.id)||{})):defaultStations)
     .filter(s=>!hidden.has(s.id));
   saveLocal();
 }
 $('results').innerHTML='<div class="small">Saisis une adresse de départ puis touche Simuler pour afficher jusqu’à 20 bornes selon le prix et la distance.</div>';
 if($('dataFreshness')){
   let teslaDate=metadata.teslaUpdated||'inconnue';
   let fxState=getFxState();
   let fxDate=fxState.updated||metadata.fxUpdated||'inconnue';
   let checked='';
   if(fxState.checkedAt){
     let d=new Date(fxState.checkedAt);
     checked=Number.isNaN(d.getTime())?'':`<br>Dernière vérification : ${d.toLocaleString('fr-FR')}`;
   }
   $('dataFreshness').innerHTML=`Base Tesla : ${teslaDate}<br>Taux de change : ${fxDate}${checked}`;
 }
 renderStations();renderFxRates();loadGithubSettingsForm();
 let cfg=githubSettings();if(cfg.autoSync&&githubToken())syncGithubNow(true).catch(()=>{});
}).catch(err=>{
 $('results').innerHTML=`<div class="bad">Chargement des données impossible : ${err.message}</div>`;
});
buildDays();resetForm();

setInterval(()=>renderGithubLastSync(),30000);
